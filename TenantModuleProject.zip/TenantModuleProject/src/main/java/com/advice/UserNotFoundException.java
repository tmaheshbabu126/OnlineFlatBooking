package com.advice;

public class UserNotFoundException extends Exception {

}

package com.advice;

public class FlatNotFoundException extends Exception {

}

package com.advice;

public class FlatBookingNotFoundException extends Exception {

}

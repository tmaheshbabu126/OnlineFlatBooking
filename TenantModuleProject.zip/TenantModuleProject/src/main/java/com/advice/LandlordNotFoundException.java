package com.advice;

public class LandlordNotFoundException extends Exception {

}
